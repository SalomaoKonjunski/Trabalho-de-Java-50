
package model;

public interface ICadastro {
    void cadastrar();
    void listar();
    void atualizar();
    void remover();
}
